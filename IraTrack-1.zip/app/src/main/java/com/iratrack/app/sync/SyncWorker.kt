package com.iratrack.app.sync

import android.content.Context
import androidx.work.*
import com.iratrack.app.data.*
import com.iratrack.app.providers.Adapters
import com.iratrack.app.security.CredentialStore
import java.util.concurrent.TimeUnit

class SyncWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val db = AppDatabase.get(applicationContext)
        val creds = CredentialStore(applicationContext)
        var successes = 0

        ProviderId.entries.forEach { provider ->
            val key = creds.get(provider.name)
            if (key.isNullOrBlank()) return@forEach

            val result = Adapters.get(provider).sync(key)

            if (result.records.isNotEmpty()) {
                db.usageDao().insertAll(result.records)
            }

            db.providerStateDao().upsert(
                ProviderState(
                    provider = provider.name,
                    enabled = true,
                    lastSync = System.currentTimeMillis(),
                    lastStatus = result.statusMessage,
                    success = result.success
                )
            )

            if (result.success) successes++
        }

        return if (successes > 0) Result.success() else Result.success()
    }

    companion object {
        fun schedule(context: Context) {
            val request = PeriodicWorkRequestBuilder<SyncWorker>(6, TimeUnit.HOURS)
                .setConstraints(
                    Constraints.Builder()
                        .setRequiredNetworkType(NetworkType.CONNECTED)
                        .build()
                )
                .build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                "iratrack_periodic_sync",
                ExistingPeriodicWorkPolicy.UPDATE,
                request
            )
        }
    }
}
